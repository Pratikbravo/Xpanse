/// <reference types="next" />
/// <reference types="next/image-types/global" />

/** This file should not be edited */